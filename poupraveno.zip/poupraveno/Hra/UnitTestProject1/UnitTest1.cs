﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Hra;
using System.Security.Cryptography;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_InitialPozice_ShouldBeZero()
        {
            var postava = new HerniPostava();
            Assert.AreEqual(0, postava.PoziceX);
            Assert.AreEqual(0, postava.PoziceY);
        }

        [TestMethod]
        public void Test_ZmenaPozice_ShouldUpdatePosition()
        {
            var postava = new HerniPostava();
            postava.ZmenaPozice(5, 10);
            Assert.AreEqual(5, postava.PoziceX);
            Assert.AreEqual(10, postava.PoziceY);
        }

        [TestMethod]
        public void Test_ToString_ShouldReturnCorrectFormat()
        {
            var postava = new HerniPostava();
            var result = postava.ToString();
            Assert.AreEqual("Jméno: Postava, Level: 1, Pozice: (0, 0)", result);
        }

        [TestMethod]
        public void Test_SetJmeno_TooLong_ThrowsException()
        {
            /* TOHLE JSME TU MELY PUVODNE
            var exception = Assert.Throws<Exception>(() => new HerniPostava());
            Assert.AreEqual("Příliš dlouhé jméno!", exception.Message);*/
            
            var postava = new HerniPostava();
            postava.Jmeno = "PřílišDlouhéJméno";
            Assert.AreNotEqual("PřílišDlouhéJméno", postava.Jmeno);
        }

        [TestMethod]
        public void Test_SetJmeno_Valid()
        {
            var postava = new HerniPostava();
            postava.Jmeno = "Krátké";
            Assert.AreEqual("Krátké", postava.Jmeno);
        }

        [TestMethod]
        public void Test_PridejXP_ShouldIncreaseLevel()
        {
            var hrac = new HerniPostava();
            hrac.PridejXP(150); // Přičteme 150 XP (pro level 2)
            Assert.AreEqual(2, hrac.Level);  // Hráč by měl být na levelu 2
        }

        [TestMethod]
        public void Test_PridejXP_ShouldNotIncreaseLevel()
        {
            /* TOHLE JSME TU MELY PUVODNE
            var hrac = new HerniPostava();
            hrac.PridejXP(50); // Přičteme 50 XP (nejsme ještě na hranici pro level up)
            Assert.AreEqual(1, hrac.Level);  // Level by měl zůstat na 1
            */
            
            var hrac = new Hrac();
            hrac.PridejXP(50);
            Assert.AreEqual(1, hrac.Level);
             
        }

        [TestMethod]
        public void Test_SetPrace_ShouldBeCorrect()
        {
            var npc = new NPC();
            Assert.AreEqual("obchodník", npc.prace);
        }

        [TestMethod]
        public void Test_StaticPozice_CannotChangeOnceSet()
        {
            var npc = new NPC();
            npc.ZmenaPozice(10, 20); // Nastavení pozice
            Assert.AreEqual(10, npc.PoziceX);
            Assert.AreEqual(20, npc.PoziceY);

            npc.ZmenaPozice(30, 40); // Pokus o změnu pozice
            Assert.AreEqual(10, npc.PoziceX);  // Pozice by měla zůstat původní
            Assert.AreEqual(20, npc.PoziceY);
        }

        [TestMethod]
        public void Test_SetSpecializace_Valid()
        {
            var hrac = new Hrac();
            Assert.AreEqual("Kouzelník", hrac.Specializace);
        }

        [TestMethod]
        public void Test_SetSpecializace_Invalid_ThrowsException()
        {
            /* TOHLE JSME TU MELY PUVODNE
            var exception = Assert.Throws<ArgumentException>(() => new Hrac("Hrac", "InvalidSpecializace"));
            Assert.AreEqual("Nevalidní specializace!", exception.Message);
            */
            
            var exception = Assert.ThrowsException<ArgumentException>(() => new Hrac());
            Assert.AreEqual("Nevalidní specializace!", exception.Message);
        }
        /*
        TOHLE BYLO POSLEDNÍ CO JSME MELY, TYHLE POD TÍM JSEM PRIDALA
         */

        [TestMethod]
        public void Test_SetXP_NegativeValue_ShouldNotChange()
        {
            var hrac = new Hrac();
            hrac.PridejXP(-50);
            Assert.AreEqual(0, hrac.XP);
        }

        [TestMethod]
        public void Test_NPC_IsBoss_ShouldBeTrue()
        {
            var npc = new NPC();
            Assert.IsTrue(npc.IsBoss);
        }

        [TestMethod]
        public void Test_NPC_IsBoss_ShouldBeFalse()
        {
            var npc = new NPC();
            Assert.IsFalse(npc.IsBoss);
        }

        [TestMethod]
        public void Test_Hrac_ToString_ShouldReturnCorrectFormat()
        {
            var hrac = new Hrac();
            string expectedOutput = "Jméno: Hero, Level: 1, XP: 0, Specializace: Kouzelník";
            Assert.AreEqual(expectedOutput, hrac.ToString());
        }

        [TestMethod]
        public void Test_NPC_ToString_ShouldReturnCorrectFormat()
        {
            var npc = new NPC();
            string expectedOutput = "Jméno: Merchant, Level: 1, Pozice: (0, 0), Práce: obchodník, Boss: Ne";
            Assert.AreEqual(expectedOutput, npc.ToString());
        }

        [TestMethod]
        public void Test_Hrac_InitialXP_ShouldBeZero()
        {
            var hrac = new Hrac();
            Assert.AreEqual(0, hrac.XP);
        }

        [TestMethod]
        public void Test_Hrac_LevelUp_MultipleTimes()
        {
            var hrac = new Hrac();
            hrac.PridejXP(300);
            Assert.AreEqual(3, hrac.Level);
        }

        [TestMethod]
        public void Test_NPC_DefaultBossValue_ShouldBeFalse()
        {
            var npc = new NPC();
            Assert.IsFalse(npc.IsBoss);
        }

        [TestMethod]
        public void Test_Hrac_SpecializaceChange_ShouldNotAllowInvalid()
        {
            var hrac = new Hrac();
            hrac.Specializace = "Rytíř";
            Assert.AreNotEqual("Rytíř", hrac.Specializace);
        }
    }
}
