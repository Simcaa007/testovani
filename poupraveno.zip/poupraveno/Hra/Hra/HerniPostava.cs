﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hra
{
    public class HerniPostava
    {
        public int PoziceX;
        public int PoziceY;
        public string Jmeno;
        public int Xp;
        public int Level;


        public void ZmenaPozice(int x, int y)
        {

        }

        public void PridejXP(int Xp)
        {

        }
    }
}
