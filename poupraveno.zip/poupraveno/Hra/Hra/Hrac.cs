﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hra
{
    /*
    public enum Oblicej { VelkyNos, Usplospek, Makeup }
    public enum Vlasy { Drdol, Culik, Pleska }
    public enum BarvaVlasu { Kastanova, Blond, Cervena }
    */
    

    public class Hrac : HerniPostava
    {
        /*
        private Oblicej oblicej = Oblicej.VelkyNos;
        private Vlasy vlasy = Vlasy.Drdol;
        private BarvaVlasu barvaVlasu = BarvaVlasu.Kastanova;
        */

        public int XP { get; private set; } = 0;

        private string specializace;
        public string Specializace;
        public string hrac;
    }
}
