﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hra

{
    public class NPC : HerniPostava
    {
        public string Npc;
        public string prace;

        //PRIDALA JSEM JA
        public bool IsBoss { get; set; }
    }
}
